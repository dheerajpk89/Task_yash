package com.org.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

@Path("rx-app")
public class Controller {
	@GET
	@Path("/getInfo")
	public Response savePayment() {
		return Response.status(200).entity("JAX-RX working Hmmmm.!").build();
	}
}
