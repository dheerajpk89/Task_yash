package com.org.dao;

public class BootCassandraDao {

}
