package com.org.controler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.org.bean.EmployeeDetailsBean;
import com.org.entity.EmpDetails;
import com.org.services.BootCassandraServices;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/cassandra")
public class BootCassandraControler {
	
	@Autowired
	private BootCassandraServices bootCassandraServices;

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@ApiOperation(value = "Get Info", response = List.class)
	@RequestMapping(value = "/getInfo/{id}", method = RequestMethod.GET)
	public List<EmpDetails> getInfoCassandra(@PathVariable int id) {
		return bootCassandraServices.getInfoCassandra(id);
	}

	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	@ApiOperation(value = "Create Info", response = ResponseEntity.class)
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ResponseEntity createEmployee(
			@ApiParam(value = "object store in database", required = true) @RequestBody EmployeeDetailsBean employeeDetailsBean) {
		bootCassandraServices.createEmployee(employeeDetailsBean);
		return new ResponseEntity<>("Create Sucesfully..!", HttpStatus.CREATED);
	}

}
