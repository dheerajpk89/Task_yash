package com.org.controler;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.org.services.BootCassandraServices;

@RestController
@RequestMapping("/cassandra")
public class BootCassandraControler {
 private BootCassandraServices bootCassandraServices;
	
	@RequestMapping(value = "/getInfo/{id}",method = RequestMethod.GET)
	public String getInfoCassandra(@PathVariable int id){
		bootCassandraServices.getInfoCassandra(id);
		return "";
	}
}
