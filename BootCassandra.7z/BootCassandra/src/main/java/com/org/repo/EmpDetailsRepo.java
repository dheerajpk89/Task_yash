package com.org.repo;

import java.util.UUID;

import org.springframework.data.repository.CrudRepository;

import com.org.entity.EmpDetails;

public interface  EmpDetailsRepo extends CrudRepository<EmpDetails, UUID>{

}
