package com.org.repo;

import java.util.List;

import org.springframework.data.cassandra.core.CassandraOperations;
import org.springframework.stereotype.Service;
import com.datastax.driver.core.querybuilder.QueryBuilder;
import com.datastax.driver.core.querybuilder.Select;
import com.org.bean.EmpDetails;

@Service
public class BootCassandraRepo {
	
	private final CassandraOperations cassandraTemplate;
	
	public BootCassandraRepo(CassandraOperations cassandraTemplate) {
        this.cassandraTemplate = cassandraTemplate;
    }
	
	    public List<EmpDetails> getInfoCassandra(int id) {
	        Select select = QueryBuilder.select().from("EmpDetails");
	        select.where(QueryBuilder.eq("id", id));
	        return this.cassandraTemplate.select(select, EmpDetails.class);
	    }
}
