package com.org.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.entity.EmpDetails;

@Service
public class BootCassandraRepo {

	@Autowired
	EmpDetailsRepo empDetailsRepo;

	public List<EmpDetails> getInfoCassandra(int id) {
		return (List<EmpDetails>) empDetailsRepo.findAll();
	}

	public String createEmployee(EmpDetails empDetails) {
		System.out.println("===>" + empDetails.toString());
		empDetailsRepo.save(empDetails);
		return "";
	}
}
