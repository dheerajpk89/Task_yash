package com.org.bean;

import java.util.UUID;

import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Table("EmpDetails")
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class EmpDetails {
	@PrimaryKey
	private UUID id;
	private int idd;
	private String fname;
	private String lname;
	private String mname;
}
