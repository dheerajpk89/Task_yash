package com.org.bean;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeDetailsBean {
	@ApiModelProperty
	private int idd;

	@ApiModelProperty
	private String fname;

	@ApiModelProperty
	private String lname;

	@ApiModelProperty
	private String mname;

}
