package com.org.services;

import java.util.List;

import com.org.bean.EmployeeDetailsBean;
import com.org.entity.EmpDetails;

public interface BootCassandraServices {
	public List<EmpDetails> getInfoCassandra(int id);

	public String createEmployee(EmployeeDetailsBean employeeDetailsBean);
}
