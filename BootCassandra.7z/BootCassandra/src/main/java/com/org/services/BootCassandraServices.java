package com.org.services;

public interface BootCassandraServices {
	public String getInfoCassandra(int id);
}
