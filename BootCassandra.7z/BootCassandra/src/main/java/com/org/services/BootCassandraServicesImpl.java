package com.org.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.org.bean.EmpDetails;
import com.org.repo.BootCassandraRepo;

public class BootCassandraServicesImpl implements BootCassandraServices {
	@Autowired
	BootCassandraRepo bootCassandraRepo;

	@Override
	public String getInfoCassandra(int id) {
		List<EmpDetails>val=bootCassandraRepo.getInfoCassandra(id);
		System.out.println("===>"+val);
		return "";
	}

}
