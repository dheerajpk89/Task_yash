package com.org.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.bean.EmployeeDetailsBean;
import com.org.entity.EmpDetails;
import com.org.repo.BootCassandraRepo;

@Service
public class BootCassandraServicesImpl implements BootCassandraServices {
	@Autowired
	BootCassandraRepo bootCassandraRepo;
	
	@Override
	public List<EmpDetails> getInfoCassandra(int id) {
		List<EmpDetails> newList=new ArrayList<>();
		List<EmpDetails>val=bootCassandraRepo.getInfoCassandra(id);
		System.out.println("===>"+val);
		val.stream()
		   .filter(emp -> emp.getFname().equals("Bobby"))
		   .map(emp->newList.add(emp))
		   .collect(Collectors.toList());
		return newList;
	}
	
	public String createEmployee(EmployeeDetailsBean employeeDetailsBean) {
		System.out.println("===>"+employeeDetailsBean.toString());
		return bootCassandraRepo.createEmployee(beanToEntity(employeeDetailsBean));
	}
	
	private EmpDetails beanToEntity(EmployeeDetailsBean employeeDetailsBean) {
		return EmpDetails.builder()
				.id(UUID.randomUUID())
				.fname(employeeDetailsBean.getFname())
				.lname(employeeDetailsBean.getLname())
				.mname(employeeDetailsBean.getMname())
				.idd(employeeDetailsBean.getIdd()).build();
	}

}
