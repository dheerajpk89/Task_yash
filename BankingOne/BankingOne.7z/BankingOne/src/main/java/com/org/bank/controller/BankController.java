package com.org.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.org.bank.bean.BankAccountPersonDetails;
import com.org.bank.services.BankServices;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class BankController {
	@Autowired
	BankServices bankServices;

	@RequestMapping(value = "/getBankDetails/{id}", method = RequestMethod.GET)
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successfully retrieved list"),
		    @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
		    @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
		    @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
		})
	@ApiOperation(value = "Get Bank Details", response = List.class)
	private BankAccountPersonDetails getBankDetails(
			 @ApiParam(value = "Employee object store in database table", required = true) @PathVariable final String id) {
		if (id.equals("ICIC202920")) {
			return insilasePerson();
		} else {
			return BankAccountPersonDetails.builder().message("Error : account does not exist").build();
		}
	}

	@RequestMapping(value = "/createAccount", method = RequestMethod.POST)
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successfully retrieved list"),
		    @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
		    @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
		    @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
		})
	@ApiOperation(value = "Create Bank Account", response = List.class)
	private String createAccount(
			@ApiParam(value = "Employee object store in database table", required = true) 
			@RequestBody final BankAccountPersonDetails bankAccountPersonDetails) {
		String id = bankServices.createUser(bankAccountPersonDetails);
		System.out.println("-->" + id);
		return id;
	}
	@RequestMapping(value = "/getAccountDetail/{id}", method = RequestMethod.GET)
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successfully retrieved list"),
		    @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
		    @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
		    @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
		})
	@ApiOperation(value = "Get Account Detail by ID", response = List.class)
	private BankAccountPersonDetails getAccountDetail(
			@ApiParam(value = "Employee object store in database table", required = true) 
			@PathVariable final String id) {
		BankAccountPersonDetails bdetail= bankServices.getAccountDetail(id);
		System.out.println("-->" + id);
		return bdetail;
	}

	@RequestMapping(value = "/updateBankDetails", method = RequestMethod.PATCH)
	@ApiResponses(value = {
		    @ApiResponse(code = 200, message = "Successfully retrieved list"),
		    @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
		    @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
		    @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
		})
	@ApiOperation(value = "Update Account Detail by ID", response = List.class)
	private BankAccountPersonDetails updateBankDetails(
			@ApiParam(value = "Employee object store in database table", required = true) 
			@RequestBody final BankAccountPersonDetails bankAccountPersonDetails) throws Exception {

		if (bankAccountPersonDetails.getAccountNumber().equals("ICIC202920")) {

			BankAccountPersonDetails bankAccountPersonDetailsOld = insilasePerson();
			if (bankAccountPersonDetailsOld.getBalanceAmount() > bankAccountPersonDetails.getBalanceAmount()) {
				bankAccountPersonDetails.setBalanceAmount(
						bankAccountPersonDetailsOld.getBalanceAmount() - bankAccountPersonDetails.getBalanceAmount());
				bankAccountPersonDetails.setMessage("Details Update Successfully..!");
				return bankAccountPersonDetails;
			} else {
				return BankAccountPersonDetails.builder().message("Error : Insufficient balance Amount..!").build();
			}
		} else {
			return BankAccountPersonDetails.builder().message("Error : account does not exist").build();
		}
	}

	private static BankAccountPersonDetails insilasePerson() {
		return BankAccountPersonDetails.builder()
				.accountNumber("ICIC202920")
				.balanceAmount(10000)
				.fName("Boby")
				.lName("S")
				.mName("das")
				.message("Account found .!").build();
	}
}
