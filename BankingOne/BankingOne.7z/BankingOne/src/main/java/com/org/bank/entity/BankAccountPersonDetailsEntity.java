package com.org.bank.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "BankAccountPersonDetails")
public class BankAccountPersonDetailsEntity {

	@Id
	@ApiModelProperty
    public String id;
	
	@Field(value = "f_name")
	@ApiModelProperty
	private String fName;
	
	@Field(value = "l_name")
	@ApiModelProperty
	private String lName;
	
	@Field(value = "m_name")
	@ApiModelProperty
	private String mName;
	
	@Field(value = "account_number")
	@ApiModelProperty
	private String accountNumber;
	
	@Field(value = "balance_amount")
	@ApiModelProperty
	private Integer balanceAmount;
	
	@Field(value = "message")
	@ApiModelProperty
	private String  message;
}
